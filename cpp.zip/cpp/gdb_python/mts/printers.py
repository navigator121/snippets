import gdb
import re
import datetime
from libstdcxx.v6.printers import StdStringPrinter

class QadDatePrinter:
    "Print a QadDate as YYYY-MM-DD (or NullDate)"

    def __init__(self, val):
        self.val = val

    def to_string(self):
        # Make sure &QadDate works, too.
        type = self.val.type
        if type.code == gdb.TYPE_CODE_REF:
            type = type.target ()

        date = self.val['date']
        if date == -100000:
            return 'NullDate'

        d = date + 730425
        h = 100 * d - 25
        a = h / 3652425
        b = a - a / 4
        year = (100 * b + h) / 36525
        c = b + d - 365 * year - year / 4
        month = (5*c + 456)/153
        day = int(c - (153 * month - 457) / 5)

        if month > 12:
            year += 1
            month -= 12

        dt = datetime.date(year, month, day)
        return dt.isoformat();

    def display_hint (self):
        return 'string'

class SStringPrinter:
    "Print a SString as the actual string it points to"

    def __init__(self, val):
        self.val = val

    def to_string(self):
        # Make sure &SString works, too.
        type = self.val.type
        if type.code == gdb.TYPE_CODE_REF:
            type = type.target ()

        ptr = self.val['p']
        return StdStringPrinter(ptr.dereference()).to_string()

    def display_hint (self):
        return 'string'

def register_mts_printers (obj):
    "Register mts pretty-printers with objfile Obj."

    if obj == None:
        obj = gdb

    obj.pretty_printers.append (lookup_function)

def build_mts_dictionary ():
    # mts objects requiring pretty-printing.
    pretty_printers_dict[re.compile('^SString$')] = lambda val: SStringPrinter(val)
    pretty_printers_dict[re.compile('^QadDate$')] = lambda val: QadDatePrinter(val)

def lookup_function (val):
    "Look-up and return a pretty-printer that can print val."

    # Get the type.
    type = val.type

    # If it points to a reference, get the reference.
    if type.code == gdb.TYPE_CODE_REF:
        type = type.target ()

    # Get the unqualified type, stripped of typedefs.
    type = type.unqualified ().strip_typedefs ()

    # Get the type name.    
    typename = type.tag
    if typename == None:
        return None

    # Iterate over local dictionary of types to determine
    # if a printer is registered for that type.  Return an
    # instantiation of the printer if found.
    for function in pretty_printers_dict:
        if function.search (typename):
            return pretty_printers_dict[function] (val)
        
    # Cannot find a pretty printer.  Return None.
    return None

pretty_printers_dict = {}

build_mts_dictionary ()

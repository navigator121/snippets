#!/bin/bash

# Start this script from anywhere within the Accurev workspace for the MTS codes.
# e.g.
# <WORKSPACE>/src
# When asked to set up the Python interpreter, select 'python' from:
# <WORKSPACE>/src/mts/corba/python1.5/python.
#
# Suggest to use 1 Eclipse workspace per Accurev workspace to avoid conflict settings.
#
# For details, see following Confluence page:
# http://tncdoc.macbank:8080/pages/viewpage.action?pageId=55477190
#

echo $LD_LIBRARY_PATH
JAVA_HOME=/usr/prod/mts/platform/x64/jdk1.7.0_04
ECLIPSE_HOME=/usr/dev/tcc/software/eclipse/eclipse-cpp-kepler-R-linux-gtk-x86_64
WORKSPACE=`accurev info | grep Top | awk '{print $2}'`

if [ -z "$WORKSPACE" ]
then
    echo "Cannot find Accurev workspace info. Must login to Accurev first"
    exit 1
fi

# Eclipse Workspace location
# If user is on a Linux Dev PC, then prefer to use /scratch over /acwork1
# The Eclipse metadata can grow quite big over time, ranges from 10's MB to 1 or 2 GB.
# This is because of C++ file index and plugin information. 
# It can be deleted and recreated, although, personal customizations will be lost.
# To avoid that, preferences can be exported from Eclipse if needed.
if [ -z "$(hostname | grep -i 'aa')" ];
then
  ECLIPSE_WORKSPACE=/acwork1/$USER/.eclipse/`basename $WORKSPACE`
else
  ECLIPSE_WORKSPACE=/scratch/$USER/.eclipse/`basename $WORKSPACE`
fi

. $WORKSPACE/src/mts/etc/mts_env

export SYBASE_USER=$USER
export SYBASE_PASSWORD=`grep 'set password' $HOME/.sqshrc | sed 's/.*password=//'`

#----------------------------------------
# Environment variables
#----------------------------------------
export CPATH=$WORKSPACE/include:$WORKSPACE/src:$WORKSPACE/include/mts:$WORKSPACE/import/include:$CPATH
export SNAPSHOT_ROOT=$WORKSPACE
export MTS_LOCATION_CONFIG=$WORKSPACE/src/mts/corba/python1.5/mts_location_config.py
export SYBASE=/usr/prod/mts/platform/x64/sybase-15
export SYBASE_OCS=OCS-15_0
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/prod/mts/cip/python/lib:/usr/prod/prod_test/cip/build-1/lib
echo 'LD_LIBRARY_PATH'
echo $LD_LIBRARY_PATH
#----------------------------------------
# List environment variables
#----------------------------------------
cat << EOF

#########################################
# Using:
#########################################

GDB=`which gdb`
JAVA_HOME=$JAVA_HOME
ECLIPSE_HOME=$ECLIPSE_HOME
ECLIPSE_WORKSPACE=$ECLIPSE_WORKSPACE

WORKSPACE=$WORKSPACE
PATH=$PATH
MTS_LOCATION_CONFIG=$MTS_LOCATION_CONFIG

EOF

# If running on blades instead of developer Linux PC, then check xulrunner compatibility. Use the one in ~/lib if on blades.
# One or the other? Also, try delete the ~/.eclipse directory
# Google "arch linux eclipse crash xulrunner"
# -Dorg.eclipse.swt.browser.UseWebKitGTK=true
# -Dorg.eclipse.swt.browser.XULRunnerPath=~/lib/xulrunner-21.0/xulrunner

#----------------------------------------
# Run Eclipse
#----------------------------------------
exec $ECLIPSE_HOME/eclipse \
-showlocation \
-data $ECLIPSE_WORKSPACE \
-vm $JAVA_HOME/bin \
-vmargs -Xms1024m -Xmx2048m -XX:MaxPermSize=2048m -Xss1m \
-Dorg.eclipse.swt.browser.UseWebKitGTK=true \
-Dorg.eclipse.swt.browser.XULRunnerPath=/usr/dev/tcc/software.sydney/eclipse/xulrunner-21.0/xulrunner \
$*




